import React, { useState } from "react";
import axios from "axios";

const TaskCsv = () => {
  const [fileData, setFileData] = useState("");
  const uploadFile = (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append("file", fileData);
    axios({
      method: "POST",
      url: "http://localhost:5000/upload",
      data: data,
    }).then((res) => {
      alert(res.data.message);
    });
  };

  return (
    <div className="main">
      <form>
        <div>
          <input
            className="inputbox"
            type="file"
            name="file"
            onChange={(e) => setFileData(e.target.files[0])}
          />
        </div>
        <div>
          <button onClick={uploadFile}>To PSV</button>
        </div>
      </form>
    </div>
  );
};

export default TaskCsv;